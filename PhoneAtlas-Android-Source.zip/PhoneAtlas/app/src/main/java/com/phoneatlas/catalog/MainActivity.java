package com.phoneatlas.catalog;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(11,13,18), PANEL = Color.rgb(22,25,34), PANEL2 = Color.rgb(30,34,46), TEXT = Color.rgb(241,243,249), MUTED = Color.rgb(154,163,181), ACCENT = Color.rgb(167,139,250), GREEN = Color.rgb(91,208,164);
    private final List<Phone> allPhones = new ArrayList<>();
    private final Set<String> compareIds = new LinkedHashSet<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private LinearLayout listRoot, topRoot;
    private EditText searchInput;
    private Spinner brandSpinner, sortSpinner;
    private TextView countLabel, compareLabel;
    private boolean compareMode = false;
    private static final String PREFS = "phoneatlas_settings";
    private static final String API_BASE_KEY = "api_base";
    // Public demo endpoint referenced by a community GSMArena scraper project.
    // It is unofficial and may be unavailable; users can change it in Settings.
    private String apiBase = "https://gsmarena-scraper.vercel.app";

    static class Phone {
        String id, brand, name, year, os, display, chipset, ram, storage, camera, battery, dimensions, network, sourceUrl, imageUrl;
        Phone(String id, String brand, String name, String year, String os, String display, String chipset, String ram, String storage, String camera, String battery, String dimensions, String network, String sourceUrl, String imageUrl) {
            this.id=id; this.brand=brand; this.name=name; this.year=year; this.os=os; this.display=display; this.chipset=chipset; this.ram=ram; this.storage=storage; this.camera=camera; this.battery=battery; this.dimensions=dimensions; this.network=network; this.sourceUrl=sourceUrl; this.imageUrl=imageUrl;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        apiBase = getSharedPreferences(PREFS, MODE_PRIVATE).getString(API_BASE_KEY, apiBase);
        seedDemoData(); buildUi(); renderPhones();
    }

    private void seedDemoData() {
        allPhones.clear();
        allPhones.add(new Phone("n95", "Nokia", "N95 8GB", "2007", "Symbian OS 9.2, S60 3rd Edition", "2.6\" TFT, 240 × 320", "Dual ARM 11 332 MHz", "128 MB", "8 GB", "5 MP, Carl Zeiss, VGA video", "Li-Ion 1200 mAh", "99 × 53 × 21 mm", "GSM / HSDPA", "https://www.gsmarena.com/nokia_n95_8gb-2081.php", ""));
        allPhones.add(new Phone("w995", "Sony Ericsson", "W995", "2009", "Java / proprietary", "2.6\" TFT, 240 × 320", "—", "118 MB", "Memory Stick Micro", "8.1 MP, autofocus, LED flash", "Li-Po 930 mAh", "97 × 49 × 15 mm", "GSM / HSPA", "https://www.gsmarena.com/sony_ericsson_w995-2697.php", ""));
        allPhones.add(new Phone("n808", "Nokia", "808 PureView", "2012", "Nokia Belle", "4.0\" AMOLED, 360 × 640", "1.3 GHz ARM 11", "512 MB", "16 GB", "41 MP, Xenon flash", "Li-Ion 1400 mAh", "123.9 × 60.2 × 13.9 mm", "GSM / HSPA", "https://www.gsmarena.com/nokia_808_pureview-4577.php", ""));
        allPhones.add(new Phone("hd2", "HTC", "HD2", "2009", "Windows Mobile 6.5", "4.3\" TFT, 480 × 800", "Snapdragon QSD8250", "448 MB", "512 MB", "5 MP, dual-LED flash", "Li-Ion 1230 mAh", "120.5 × 67 × 11 mm", "GSM / HSPA", "https://www.gsmarena.com/htc_hd2-2957.php", ""));
        allPhones.add(new Phone("iphone4", "Apple", "iPhone 4", "2010", "iOS 4, upgradable", "3.5\" IPS LCD, 640 × 960", "Apple A4", "512 MB", "8/16/32 GB", "5 MP, LED flash, 720p video", "Li-Po 1420 mAh", "115.2 × 58.6 × 9.3 mm", "GSM / CDMA variants", "https://www.gsmarena.com/apple_iphone_4-3275.php", ""));
        allPhones.add(new Phone("lumia920", "Nokia", "Lumia 920", "2012", "Windows Phone 8", "4.5\" IPS LCD, 768 × 1280", "Snapdragon S4 Plus", "1 GB", "32 GB", "8.7 MP PureView, OIS", "Li-Ion 2000 mAh", "130.3 × 70.8 × 10.7 mm", "LTE", "https://www.gsmarena.com/nokia_lumia_920-4967.php", ""));
        allPhones.add(new Phone("motoG", "Motorola", "Moto G (1st gen)", "2013", "Android 4.3, upgradable", "4.5\" IPS LCD, 720 × 1280", "Snapdragon 400", "1 GB", "8/16 GB", "5 MP, 720p video", "Li-Ion 2070 mAh", "129.9 × 65.9 × 11.6 mm", "GSM / HSPA", "https://www.gsmarena.com/motorola_moto_g-5831.php", ""));
        allPhones.add(new Phone("galaxys7", "Samsung", "Galaxy S7", "2016", "Android 6, upgradable", "5.1\" Super AMOLED, 1440 × 2560", "Exynos 8890 / Snapdragon 820", "4 GB", "32/64 GB", "12 MP, OIS, Dual Pixel", "Li-Ion 3000 mAh", "142.4 × 69.6 × 7.9 mm", "LTE", "https://www.gsmarena.com/samsung_galaxy_s7-7821.php", ""));
        allPhones.add(new Phone("mia2", "Xiaomi", "Mi A2", "2018", "Android One", "5.99\" IPS LCD, 1080 × 2160", "Snapdragon 660", "4/6 GB", "32/64/128 GB", "12 + 20 MP, 4K video", "Li-Po 3010 mAh", "158.7 × 75.4 × 7.3 mm", "LTE", "https://www.gsmarena.com/xiaomi_mi_a2_(mi_6x)-9140.php", ""));
        allPhones.add(new Phone("iphone15pm", "Apple", "iPhone 15 Pro Max", "2023", "iOS 17, upgradable", "6.7\" LTPO OLED, 120 Hz", "Apple A17 Pro", "8 GB", "256 GB–1 TB", "48 + 12 + 12 MP", "Li-Ion, wired / MagSafe charging", "159.9 × 76.7 × 8.3 mm", "5G", "https://www.gsmarena.com/apple_iphone_15_pro_max-12548.php", ""));
        allPhones.add(new Phone("s24u", "Samsung", "Galaxy S24 Ultra", "2024", "Android 14, upgradable", "6.8\" Dynamic AMOLED 2X, 120 Hz", "Snapdragon 8 Gen 3 for Galaxy", "12 GB", "256 GB–1 TB", "200 + 50 + 10 + 12 MP", "Li-Ion 5000 mAh", "162.3 × 79.0 × 8.6 mm", "5G", "https://www.gsmarena.com/samsung_galaxy_s24_ultra-12771.php", ""));
        allPhones.add(new Phone("pixel9pro", "Google", "Pixel 9 Pro", "2024", "Android 14, upgradable", "6.3\" LTPO OLED, 120 Hz", "Google Tensor G4", "16 GB", "128 GB–1 TB", "50 + 48 + 48 MP", "Li-Ion 4700 mAh", "152.8 × 72.0 × 8.5 mm", "5G", "https://www.gsmarena.com/google_pixel_9_pro-13217.php", ""));
        allPhones.add(new Phone("iphone17pm", "Apple", "iPhone 17 Pro Max", "2025", "iOS 26 generation", "Large OLED, 120 Hz", "Apple A-series (verify source)", "—", "—", "Multi-camera system", "—", "—", "5G", "https://www.gsmarena.com/", ""));
    }

    private void buildUi() {
        ScrollView page = new ScrollView(this); page.setFillViewport(true); page.setBackgroundColor(BG);
        topRoot = new LinearLayout(this); topRoot.setOrientation(LinearLayout.VERTICAL); topRoot.setPadding(dp(18),dp(16),dp(18),dp(24)); page.addView(topRoot);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout titleBox = new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow = text("PHONE ATLAS  /  DEVICE LIBRARY", 10, ACCENT, true); titleBox.addView(eyebrow);
        TextView title = text("Телефони", 30, TEXT, true); titleBox.addView(title);
        TextView subtitle = text("Від класики до сучасних флагманів", 13, MUTED, false); titleBox.addView(subtitle);
        header.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));
        Button settings = button("⚙", PANEL2); settings.setOnClickListener(v -> showApiSettings()); header.addView(settings,new LinearLayout.LayoutParams(dp(48),dp(44)));
        topRoot.addView(header); space(topRoot,18);
        searchInput = new EditText(this); searchInput.setSingleLine(true); searchInput.setTextColor(TEXT); searchInput.setHintTextColor(MUTED); searchInput.setHint("Пошук моделі, бренду або року…"); searchInput.setTextSize(14); searchInput.setPadding(dp(14),0,dp(14),0); searchInput.setBackground(bg(PANEL2,14)); searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH); topRoot.addView(searchInput,new LinearLayout.LayoutParams(-1,dp(52)));
        searchInput.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderPhones();} public void afterTextChanged(Editable e){} });
        space(topRoot,12);
        LinearLayout filters = new LinearLayout(this); filters.setOrientation(LinearLayout.HORIZONTAL); filters.setGravity(Gravity.CENTER_VERTICAL);
        brandSpinner = new Spinner(this); sortSpinner = new Spinner(this);
        styleSpinner(brandSpinner); styleSpinner(sortSpinner);
        filters.addView(brandSpinner,new LinearLayout.LayoutParams(0,dp(46),1)); filters.addView(gapView(dp(8),1)); filters.addView(sortSpinner,new LinearLayout.LayoutParams(0,dp(46),1)); topRoot.addView(filters);
        ArrayAdapter<String> brands = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, brandNames()); brandSpinner.setAdapter(brands);
        ArrayAdapter<String> sorts = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Спочатку нові", "Спочатку старі", "Назва A–Я"}); sortSpinner.setAdapter(sorts);
        brandSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){renderPhones();}});
        sortSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){renderPhones();}});
        space(topRoot,14);
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL);
        countLabel = text("",12,MUTED,false); controls.addView(countLabel,new LinearLayout.LayoutParams(0,-2,1));
        Button compare = button("⇄ Порівняти", ACCENT); compare.setTextColor(Color.rgb(17,14,30)); compare.setOnClickListener(v->{compareMode=!compareMode; compare.setText(compareMode?"Готово":"⇄ Порівняти"); renderPhones();}); controls.addView(compare);
        Button refresh = button("↻", PANEL2); refresh.setOnClickListener(v->refreshFromApi()); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(dp(44),dp(42)); rp.leftMargin=dp(8); controls.addView(refresh,rp);
        topRoot.addView(controls); space(topRoot,8);
        compareLabel = text("",11,ACCENT,false); topRoot.addView(compareLabel); space(topRoot,8);
        listRoot = new LinearLayout(this); listRoot.setOrientation(LinearLayout.VERTICAL); topRoot.addView(listRoot);
        setContentView(page);
    }

    private String[] brandNames(){ Set<String>s=new LinkedHashSet<>();s.add("Усі бренди");for(Phone p:allPhones)s.add(p.brand);return s.toArray(new String[0]); }
    private void styleSpinner(Spinner s){s.setBackground(bg(PANEL2,12));s.setPadding(dp(8),0,dp(6),0);}

    private void renderPhones(){ if(listRoot==null)return; listRoot.removeAllViews(); String q=searchInput==null?"":searchInput.getText().toString().trim().toLowerCase(Locale.ROOT); String brand=brandSpinner==null||brandSpinner.getSelectedItem()==null?"Усі бренди":brandSpinner.getSelectedItem().toString(); List<Phone> result=new ArrayList<>();
        for(Phone p:allPhones){String hay=(p.brand+" "+p.name+" "+p.year+" "+p.os+" "+p.chipset).toLowerCase(Locale.ROOT);if(!hay.contains(q))continue;if(!brand.equals("Усі бренди")&&!p.brand.equals(brand))continue;result.add(p);}
        int sort=sortSpinner==null?0:sortSpinner.getSelectedItemPosition();if(sort==0)Collections.sort(result,(a,b)->year(b.year)-year(a.year));else if(sort==1)Collections.sort(result,(a,b)->year(a.year)-year(b.year));else Collections.sort(result,Comparator.comparing(a->a.name.toLowerCase(Locale.ROOT)));
        countLabel.setText(result.size()+" моделей  ·  "+(apiBase.isEmpty()?"демо-каталог":"API налаштовано")); compareLabel.setText(compareMode?"Вибрано для порівняння: "+compareIds.size()+" / 3":"");
        if(result.isEmpty()){TextView empty=text("Нічого не знайдено. Спробуй інший запит.",14,MUTED,false);empty.setPadding(0,dp(28),0,dp(28));listRoot.addView(empty);return;}
        for(Phone p:result)listRoot.addView(phoneCard(p));
    }

    private View phoneCard(Phone p){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(14),dp(14),dp(14));card.setBackground(bg(PANEL,18));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(10);card.setLayoutParams(cp);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon=text(monogram(p.brand),22,ACCENT,true);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(PANEL2,14));row.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(70)));
        LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);details.setPadding(dp(12),0,dp(6),0);
        TextView brand=text(p.brand.toUpperCase(Locale.ROOT)+"  ·  "+p.year,10,MUTED,true);details.addView(brand);
        TextView name=text(p.name,17,TEXT,true);details.addView(name);TextView spec=text(shortSpec(p),12,MUTED,false);details.addView(spec);
        row.addView(details,new LinearLayout.LayoutParams(0,-2,1));
        if(compareMode){CheckBox cb=new CheckBox(this);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));cb.setChecked(compareIds.contains(p.id));cb.setOnCheckedChangeListener((b,checked)->{if(checked&&compareIds.size()>=3){b.setChecked(false);Toast.makeText(this,"Можна порівняти до 3 телефонів",Toast.LENGTH_SHORT).show();return;}if(checked)compareIds.add(p.id);else compareIds.remove(p.id);renderPhones();});row.addView(cb);}
        card.addView(row);space(card,12);LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
        Button detailsBtn=button("Характеристики  ↗",PANEL2);detailsBtn.setOnClickListener(v->showDetails(p));actions.addView(detailsBtn,new LinearLayout.LayoutParams(0,dp(40),1));
        Button webBtn=button("GSMArena",PANEL2);webBtn.setOnClickListener(v->{if(p.sourceUrl!=null&&!p.sourceUrl.isEmpty())startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(p.sourceUrl)));else Toast.makeText(this,"Посилання для цієї моделі не задане",Toast.LENGTH_SHORT).show();});LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(dp(100),dp(40));wp.leftMargin=dp(8);actions.addView(webBtn,wp);card.addView(actions);
        card.setOnClickListener(v->{if(!compareMode)showDetails(p);});return card;
    }

    private void showDetails(Phone p){LinearLayout box=new LinearLayout(this);box.setPadding(dp(20),dp(8),dp(20),dp(8));box.setOrientation(LinearLayout.VERTICAL);ScrollView scroll=new ScrollView(this);scroll.addView(box);
        TextView heading=text(p.brand+"  /  "+p.name,22,TEXT,true);box.addView(heading);TextView year=text("Рік: "+p.year,13,ACCENT,true);box.addView(year);space(box,12);
        addSpec(box,"Операційна система",p.os);addSpec(box,"Дисплей",p.display);addSpec(box,"Чипсет",p.chipset);addSpec(box,"Оперативна пам'ять",p.ram);addSpec(box,"Накопичувач",p.storage);addSpec(box,"Камери",p.camera);addSpec(box,"Акумулятор",p.battery);addSpec(box,"Розміри",p.dimensions);addSpec(box,"Мережі",p.network);
        new AlertDialog.Builder(this).setView(scroll).setPositiveButton("Закрити",null).setNeutralButton("Порівняти",(d,w)->{if(compareIds.contains(p.id))compareIds.remove(p.id);else if(compareIds.size()<3)compareIds.add(p.id);else Toast.makeText(this,"Максимум 3 телефони",Toast.LENGTH_SHORT).show();renderPhones();if(compareIds.size()>=2)showComparison();}).show();
    }
    private void addSpec(LinearLayout root,String k,String v){LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.VERTICAL);line.setPadding(0,dp(7),0,dp(7));TextView key=text(k.toUpperCase(Locale.ROOT),10,MUTED,true);line.addView(key);TextView val=text(v==null||v.isEmpty()?"—":v,14,TEXT,false);line.addView(val);root.addView(line);View divider=new View(this);divider.setBackgroundColor(PANEL2);root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));}

    private void showComparison(){if(compareIds.size()<2){Toast.makeText(this,"Обери щонайменше 2 телефони",Toast.LENGTH_SHORT).show();return;}LinearLayout box=new LinearLayout(this);box.setPadding(dp(16),dp(8),dp(16),dp(8));box.setOrientation(LinearLayout.VERTICAL);ScrollView scroll=new ScrollView(this);scroll.addView(box);List<Phone> selected=new ArrayList<>();for(Phone p:allPhones)if(compareIds.contains(p.id))selected.add(p);
        String[] keys={"Рік","ОС","Дисплей","Чипсет","RAM","Пам'ять","Камери","Батарея","Розміри"};for(Phone p:selected){TextView title=text(p.brand+" "+p.name,18,ACCENT,true);box.addView(title);String[] vals={p.year,p.os,p.display,p.chipset,p.ram,p.storage,p.camera,p.battery,p.dimensions};for(int i=0;i<keys.length;i++)addSpec(box,keys[i],vals[i]);space(box,12);}new AlertDialog.Builder(this).setTitle("Порівняння телефонів").setView(scroll).setPositiveButton("Готово",null).show();}

    private void showApiSettings(){
        EditText input=new EditText(this);input.setSingleLine(true);input.setText(apiBase);input.setHint("https://адреса-api.example");input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setPadding(dp(12),0,dp(12),0);input.setBackground(bg(PANEL2,10));
        new AlertDialog.Builder(this).setTitle("Джерело даних API")
            .setMessage("PhoneAtlas спробує пошук через GET /search?query=… і сумісні варіанти. За замовчуванням вказаний сторонній хост gsmarena-scraper.vercel.app, але його доступність не гарантована. Для надійної роботи можна вказати адресу власного сервера. Використовуй лише джерело, яке має право надавати ці дані.")
            .setView(input).setNegativeButton("Скасувати",null)
            .setNeutralButton("Демо-режим",(d,w)->{apiBase="";getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(API_BASE_KEY,apiBase).apply();renderPhones();})
            .setPositiveButton("Зберегти й перевірити",(d,w)->{apiBase=input.getText().toString().trim().replaceAll("/$","");getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(API_BASE_KEY,apiBase).apply();renderPhones();if(!apiBase.isEmpty())refreshFromApi();}).show();
    }

    private void refreshFromApi(){
        if(apiBase.isEmpty()){Toast.makeText(this,"Спочатку вкажи адресу API в ⚙ або повернись до демо-режиму",Toast.LENGTH_LONG).show();return;}
        String q=searchInput.getText().toString().trim();if(q.isEmpty()){Toast.makeText(this,"Введи назву телефону для пошуку онлайн",Toast.LENGTH_SHORT).show();return;}
        final String base=apiBase;Toast.makeText(this,"Шукаю «"+q+"» в API…",Toast.LENGTH_SHORT).show();
        io.execute(()->{
            Exception lastError=null;List<Phone> found=new ArrayList<>();String[] urls={
                base+"/search?query="+urlEncode(q),
                base+"/search?q="+urlEncode(q),
                base+"/search?name="+urlEncode(q)
            };
            for(String endpoint:urls){HttpURLConnection conn=null;try{conn=(HttpURLConnection)new URL(endpoint).openConnection();conn.setConnectTimeout(7000);conn.setReadTimeout(10000);conn.setRequestMethod("GET");conn.setRequestProperty("Accept","application/json");int code=conn.getResponseCode();if(code<200||code>=300)throw new Exception("HTTP "+code+" для "+endpoint);String raw=readResponse(conn);found=parsePhones(new JSONObject(raw));if(!found.isEmpty())break;lastError=new Exception("Відповідь не містить знайомого списку моделей");}catch(Exception e){lastError=e;}finally{if(conn!=null)conn.disconnect();}}
            // GrayHatAli-style deployments expose POST /devices/search rather than GET /search.
            if(found.isEmpty()){HttpURLConnection conn=null;try{conn=(HttpURLConnection)new URL(base+"/devices/search").openConnection();conn.setConnectTimeout(7000);conn.setReadTimeout(10000);conn.setRequestMethod("POST");conn.setDoOutput(true);conn.setRequestProperty("Content-Type","application/json; charset=utf-8");conn.setRequestProperty("Accept","application/json");byte[] body=new JSONObject().put("query",q).put("search",q).toString().getBytes(StandardCharsets.UTF_8);conn.getOutputStream().write(body);int code=conn.getResponseCode();if(code<200||code>=300)throw new Exception("HTTP "+code+" для /devices/search");found=parsePhones(new JSONObject(readResponse(conn)));if(found.isEmpty())lastError=new Exception("API відповів, але список моделей не розпізнано");}catch(Exception e){lastError=e;}finally{if(conn!=null)conn.disconnect();}}
            final List<Phone> result=found;final Exception error=lastError;
            runOnUiThread(()->{if(!result.isEmpty()){allPhones.clear();allPhones.addAll(result);compareIds.retainAll(idsOf(result));brandSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,brandNames()));renderPhones();Toast.makeText(this,"API повернув моделей: "+result.size(),Toast.LENGTH_LONG).show();}else Toast.makeText(this,"Не вдалося отримати моделі з API. "+(error==null?"Перевір адресу сервера.":error.getMessage())+" Демо-список збережено.",Toast.LENGTH_LONG).show();});
        });
    }

    private Set<String> idsOf(List<Phone> phones){Set<String> ids=new LinkedHashSet<>();for(Phone p:phones)ids.add(p.id);return ids;}
    private String urlEncode(String value){try{return URLEncoder.encode(value,"UTF-8");}catch(Exception e){return value;}}
    private String readResponse(HttpURLConnection conn)throws Exception{BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),StandardCharsets.UTF_8));StringBuilder raw=new StringBuilder();String line;while((line=reader.readLine())!=null)raw.append(line);reader.close();return raw.toString();}

    private List<Phone> parsePhones(JSONObject root){
        List<Phone> out=new ArrayList<>();JSONArray arr=findPhoneArray(root);if(arr==null)return out;
        for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;String name=first(o,"name","model","model_name","title","phone_name","device_name");if(name.isEmpty())continue;String brand=first(o,"brand","manufacturer","maker","brand_name");if(brand.isEmpty())brand=inferBrand(name);String url=first(o,"url","device_url","detail_url","phone_url","link");String image=first(o,"image","image_url","img","thumbnail","thumb");String year=first(o,"year","release_year","release_date","announced","released");String slug=first(o,"slug","id","device_id","phone_id");String display=first(o,"display","screen","screen_size","display_type");String chipset=first(o,"chipset","cpu","processor","platform");String ram=first(o,"ram","ram_size");String storage=first(o,"storage","internal_memory","memory");String camera=first(o,"camera","main_camera","camera_specs");String battery=first(o,"battery","battery_capacity");String os=first(o,"os","operating_system");String dimensions=first(o,"dimensions","body");String network=first(o,"network","technology","network_technology");
            // Some scrapers return specs grouped by category instead of flat fields.
            JSONObject specs=o.optJSONObject("specifications");if(specs==null)specs=o.optJSONObject("specs");if(specs!=null){if(display.isEmpty())display=findSpec(specs,"Display","Size","Type");if(chipset.isEmpty())chipset=findSpec(specs,"Platform","Chipset","CPU");if(os.isEmpty())os=findSpec(specs,"Platform","OS");if(ram.isEmpty())ram=findSpec(specs,"Memory","RAM");if(storage.isEmpty())storage=findSpec(specs,"Memory","Internal");if(camera.isEmpty())camera=findSpec(specs,"Main Camera","Single","Quad");if(battery.isEmpty())battery=findSpec(specs,"Battery","Type","Charging");if(dimensions.isEmpty())dimensions=findSpec(specs,"Body","Dimensions");if(network.isEmpty())network=findSpec(specs,"Network","Technology");}
            out.add(new Phone(slug.isEmpty()?"api"+i:slug,brand,name,year,os,display,chipset,ram,storage,camera,battery,dimensions,network,normalizeUrl(url),normalizeUrl(image)));
        }return out;
    }
    private JSONArray findPhoneArray(JSONObject root){
        JSONArray a=root.optJSONArray("data");if(a!=null)return a;
        a=root.optJSONArray("phones");if(a!=null)return a;a=root.optJSONArray("results");if(a!=null)return a;a=root.optJSONArray("devices");if(a!=null)return a;
        JSONObject data=root.optJSONObject("data");if(data!=null){a=data.optJSONArray("phones");if(a!=null)return a;a=data.optJSONArray("results");if(a!=null)return a;a=data.optJSONArray("devices");if(a!=null)return a;a=data.optJSONArray("results");if(a!=null)return a;
            JSONArray brands=data.optJSONArray("brands");if(brands!=null){JSONArray combined=new JSONArray();for(int i=0;i<brands.length();i++){JSONObject b=brands.optJSONObject(i);if(b==null)continue;JSONArray models=b.optJSONArray("models");if(models!=null)for(int j=0;j<models.length();j++){JSONObject m=models.optJSONObject(j);if(m!=null){try{if(m.optString("brand").isEmpty())m.put("brand",b.optString("name"));combined.put(m);}catch(Exception ignored){}}}}if(combined.length()>0)return combined;}
        }
        a=root.optJSONArray("models");if(a!=null)return a;
        return null;
    }
    private String findSpec(JSONObject specs,String category,String... keys){JSONObject group=specs.optJSONObject(category);if(group==null){java.util.Iterator<String> it=specs.keys();while(it.hasNext()){String k=it.next();if(k.toLowerCase(Locale.ROOT).contains(category.toLowerCase(Locale.ROOT))){group=specs.optJSONObject(k);if(group!=null)break;}}}if(group!=null){for(String k:keys){String v=first(group,k);if(!v.isEmpty())return v;}}for(String k:keys){String v=first(specs,k);if(!v.isEmpty())return v;}return "";}
    private String inferBrand(String name){String[] known={"Sony Ericsson","Google","Motorola","OnePlus","Nothing","Samsung","Apple","Nokia","Xiaomi","Huawei","Honor","Realme","Oppo","Vivo","Lenovo","BlackBerry","Microsoft","HTC","LG","Asus","Sony","ZTE","Meizu","Tecno","Infinix","Alcatel","Acer","Palm"};for(String b:known)if(name.toLowerCase(Locale.ROOT).startsWith(b.toLowerCase(Locale.ROOT)+" "))return b;int sp=name.indexOf(' ');return sp>0?name.substring(0,sp):name;}
    private String normalizeUrl(String url){if(url==null||url.isEmpty())return "";if(url.startsWith("//"))return "https:"+url;return url;}
    private String first(JSONObject o,String... keys){for(String k:keys){Object v=o.opt(k);if(v!=null&&!v.toString().equals("null")&&!v.toString().trim().isEmpty()&&!v.toString().equals("{}"))return v.toString();}return "";}

    private String shortSpec(Phone p){String s=p.display;if(s==null||s.isEmpty())s=p.os; if(s==null||s.isEmpty())s="Характеристики доступні в картці";return s;}
    private int year(String y){try{java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(y==null?"":y);return m.find()?Integer.parseInt(m.group()):0;}catch(Exception e){return 0;}}
    private String monogram(String b){String[] parts=b.split(" ");return parts.length>1?(parts[0].substring(0,1)+parts[1].substring(0,1)).toUpperCase(Locale.ROOT):b.substring(0,Math.min(2,b.length())).toUpperCase(Locale.ROOT);}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(TEXT);b.setPadding(dp(8),0,dp(8),0);b.setBackground(bg(color,12));return b;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private void space(LinearLayout root,int height){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private View gapView(int w,int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),dp(h)));return v;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();}
}
