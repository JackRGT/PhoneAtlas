# Build PhoneAtlas APK in a browser using GitHub Actions

1. Create a GitHub account and a new repository named `PhoneAtlas`.
2. Upload the contents of this project folder to the repository (the `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, and `.github` items must be at the repository root; do not upload the outer `PhoneAtlas` folder as an extra nesting level).
3. Open the repository's **Actions** tab and select **Build PhoneAtlas APK**.
4. Press **Run workflow**. Alternatively, pushing to `main` or `master` starts the workflow automatically.
5. Wait for the workflow to finish successfully, open its run, and download the `PhoneAtlas-debug-apk` artifact. Extract the ZIP to get `app-debug.apk`.

The workflow builds a debug APK, not a Play Store release. The APK has not been built or tested in this environment; GitHub Actions will reveal any build errors.
