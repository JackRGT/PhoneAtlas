# PhoneAtlas — Android phone catalogue prototype

Native Android starter project (Java + Android SDK views), dark modern interface.

## Included
- Search by phone, brand, year, OS and chipset
- Brand filter and year/name sorting
- Phone cards and a detailed specification dialog
- Side-by-side comparison for up to 3 devices
- Live API search from inside the app
- API URL stored in Android SharedPreferences
- Tries common search endpoints: `GET /search?query=`, `GET /search?q=`, `GET /search?name=`, then `POST /devices/search`
- Parser accepts several common JSON response shapes, including `data.phones`, `data.results`, `phones`, `results`, and brand groups containing models
- Falls back to the demo catalogue if online requests fail

## API source and limitations

The app is configured by default to try `https://gsmarena-scraper.vercel.app`. This is an unofficial community scraper host mentioned by a public project; its availability and endpoint compatibility could not be verified from this build environment. The app will attempt supported endpoint shapes on the device and show an error while preserving the demo catalogue if they do not work. Tap the gear icon to enter a different compatible API URL or switch to demo mode.

A second community implementation documents a self-hosted API with endpoints such as `GET /brands`, `POST /brands`, `GET /jobs/:id`, `GET /devices/:deviceId/specifications`, and `POST /devices/search`: https://github.com/GrayHatAli/GSM-Arena-Scraper
Another unofficial implementation documents `GET /brands`, `GET /brands/:brandSlug`, `GET /latest`, `GET /search?query=...`, and `GET /:slug`: https://github.com/RevengerNick/mobile-specs-api

These are not official GSMArena APIs and may stop working. The API must be reachable over HTTPS from the Android device. Some scraper projects must be self-hosted; this app does not host the server itself.

GSMArena's terms restrict reuse and redistribution of site content without permission. Review the current terms and obtain permission before redistributing data or images, especially in a public/commercial app: https://www.gsmarena.com/terms.php3

## Build APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this `PhoneAtlas` folder in Android Studio.
3. Let Gradle sync and install required components.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the resulting APK path, usually `app/build/outputs/apk/debug/app-debug.apk`.

Command line (after installing Gradle and Android SDK):

```bash
gradle assembleDebug
```

## How to try live API search
1. Install/run the app on a device with internet access.
2. Enter a model name in the search box, for example `Nokia N95`.
3. Tap the refresh icon (`↻`).
4. The app tries the configured API routes and shows the number of models returned. If the host is unavailable or has a different API shape, tap the gear icon and enter your own compatible server URL.

## Current limitations
- The local demo catalogue is a small sample, not the full GSMArena database.
- A public API host is not guaranteed; a reliable full catalogue may require deploying and maintaining a permitted data source.
- Live search currently fetches results for the entered query; paging, offline persistence of fetched results, image rendering, and fully normalized detailed-spec API adapters are future improvements.
- This source bundle is not a compiled APK. Android SDK/Gradle were not available in the build environment, so compilation and on-device API testing were not performed here.
